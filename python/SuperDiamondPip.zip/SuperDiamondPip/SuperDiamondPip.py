import subprocess
import sys
import os
try:
 import requests
except:
 subprocess.check_call([sys.executable, "-m", "pip", "install", "requests"])
 import requests

class SuperDiamondPipObj:
    def importPackage(packageName):
        try:
         packageFile = open(self.path + "/packages/" + package + ".py")
         packageScript = packageFile.read()
         eval(packageScript)
         return "Sucessfully Imported " + packageName
        except FileNotFoundError as e:
         return "Package " + packageName + " was not found: " + e
        except:
         return "An Unknown Error Accoured."
    
    def __init__(self):
        self.path = os.path.abspath("")
        print("SuperDiamondPip Path: " + os.path.abspath(""))
        print("SuperDiamondPip Loaded!")
import subprocess
import sys
import os
try:
 import requests
except:
 subprocess.check_call([sys.executable, "-m", "pip", "install", "requests"])
 import requests

class SuperDiamondPipObj:
    def importPackage(self, name):
        packageFile = open(self.path + "/packages/" + name + ".py")
        packageScript = packageFile.read()
        eval(packageScript)
        packageFile.close()
        return "Sucessfully Imported " + name

    def packagePath(self, name):
        return os.path.join(self.path, "packages/" + name + ".py")

    def installPackage(self, url, name):
        r = requests.get(url)
        if(r.ok):
         packagePath = os.path.join(self.path, "packages/" + name + ".py")
         packageFile = open(packagePath, "w")
         packageFile.write(r.text)
         return "Sucesfully Installed package from " + url + " as " + name
        else:
         return "Failed to read package content. Status_code: " + r.status_code
        
    
    def __init__(self):
        self.path = os.path.dirname(os.path.abspath(__file__))
        print("SuperDiamondPip path: " + self.path)
        print("SuperDiamondPip Loaded!")
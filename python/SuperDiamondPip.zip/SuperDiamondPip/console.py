import SuperDiamondPip
superdiamondpip = SuperDiamondPip.SuperDiamondPipObj()
print("SuperDiamondPip. all packages available with internet")

def execute():
    try:
     print(eval(input(">>")))
    except Exception as e:
     print(e)
    execute()

execute()